import { useState, useEffect } from "react";
import { Row, Col, Form, Container, Card, Dropdown } from "react-bootstrap";
import NavBarD from "./NavbarD";

const BASE_URL = "http://192.168.90.158:5000/api"; // Update with your backend API base URL

export default function OtherTests() {
  // const [dropdownOptions, setDropdownOptions] = useState([]); // Store API options
  const [selectedOptions, setSelectedOptions] = useState({ test_type: [] }); // Track selected checkboxes
  const [tests, setTests] = useState([]);
  const [types, setTypes] = useState([]);
  const [assistants, setAssistants] = useState([]);
  const [errors, setErrors] = useState({});
  const [isDisabled, setIsDisabled] = useState(false); // Controls edit mode
  const [disablePreviousButton, setDisablePreviousButton] = useState(false); // Disables "Previous Records" after clicking
  const [patientId, setPatientId] = useState(
    localStorage.getItem("selectedPatientId")
  );
  const [formData, setFormData] = useState({
    test_date: "",
    test_type: "",
    ref_doctor: "",
    fee_status: "",
    visit_type: "",
    test_comment: "",
  });
  const [previousRecordDate, setPreviousRecordDate] = useState("");
  const [showEditButton, setShowEditButton] = useState(false);

  useEffect(() => {
    const storedPatientId = localStorage.getItem("selectedPatientId");
    console.log("Retrieved from localStorage:", storedPatientId);
    if (storedPatientId) setPatientId(storedPatientId);
  }, []);

  useEffect(() => {
    if (!patientId) {
      console.warn("No patientId found, skipping fetch");
      return;
    }
    const fetchPatientData = async () => {
      console.log(`Fetching data for patient ID: ${patientId}`);
      try {
        const response = await fetch(
          `${BASE_URL}/V1/patienttabs/listOtherTests/${patientId}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        if (!response.ok) {
          console.error(
            "API Response Error:",
            response.status,
            await response.text()
          );
          return;
        }

        const data = await response.json();
        console.log("Fetched Data:", data);

        if (data?.data?.patientData?.length > 0) {
          setFormData(data.data.patientData[0]);
        } else {
          console.warn("No patient data found in API response");
          setFormData({});
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchPatientData();
  }, [patientId]);

  useEffect(() => {
    const fetchDropdownOptions = async () => {
      try {
        const endpoints = [
          {
            url: "/V1/patienttabsdp/assistantDoc_dropdown",
            setter: setAssistants,
          },
          {
            url: "/V1/patienttabsdp/testType_dropdown",
            setter: setTypes,
          },
        ];

        for (const { url, setter } of endpoints) {
          const response = await fetch(`${BASE_URL}${url}`);
          const data = await response.json();

          if (!response.ok) {
            throw new Error(
              `Error fetching ${url}: ${data.message || "Unknown error"}`
            );
          }

          console.log(`${url} Data:`, data.data); // Log fetched data to the console
          setter(data.data || []);
        }
      } catch (err) {
        console.error("Fetch error:", err);
        setErrors("Failed to fetch dropdown data.");
      }
    };
    fetchDropdownOptions();
  }, []);

  const handleInputChange = (e) => {
    if (isDisabled) return; // Don't update if form is disabled

    const { name, value, type, checked } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async () => {
    try {
      // Prepare the data to be sent
      const dataToSend = {
        ...formData,
        test_type: selectedOptions.test_type.join(", "), // Join selected test types into a string
        ref_doctor: selectedOptions.ref_doctor || formData.ref_doctor,
        patient_id: patientId,
      };

      console.log("Sending Data:", JSON.stringify(dataToSend, null, 2));

      const response = await fetch(
        `${BASE_URL}/V1/otherTests/addOtherTests/${patientId}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(dataToSend),
        }
      );

      const responseData = await response.json();
      console.log("Response Data:", responseData);

      if (!response.ok) {
        throw new Error(responseData.message || "Failed to save data");
      }

      alert("Form submitted successfully!");

      // Clear the form after successful submission
      setFormData({
        test_date: "",
        test_type: "",
        ref_doctor: "",
        fee_status: "",
        visit_type: "",
        test_comment: "",
      });

      // Reset selected options
      setSelectedOptions({
        test_type: [],
        ref_doctor: "",
      });
    } catch (error) {
      console.error("Error submitting form:", error);
      alert("Failed to submit form. Please try again.");
    }
  };

  // const handleSubmit = async (saveType) => {
  //   const validationErrors = validate();
  //   console.log("Form Data:", formData);
  //   setErrors(validationErrors);

  //   if (Object.keys(validationErrors).length === 0) {
  //     try {
  //       const response = await fetch(
  //         `${BASE_URL}/V1/patienttabs/otherTests/${state.patient.patient_id}`,
  //         {
  //           method: "PUT",
  //           headers: { "Content-Type": "application/json" },
  //           body: JSON.stringify({ ...formData, saveType }),
  //         }
  //       );

  //       console.log("Response received:", response);

  //       if (response.ok) {
  //         alert("Appointment added successfully");

  //         setFormData({
  //           patient_id: "",
  //           test_date: state?.test_date || "",
  //           test_type: state?.test_type || "",
  //           ref_doctor: state?.ref_doctor || "",
  //           fee_status: state?.fee_status || "",
  //           visit_type: state?.visit_type || "",
  //           test_comment: state?.test_comment || "",
  //         });
  //       } else {
  //         const errorData = await response.json();
  //         console.error("Error response from API:", errorData);
  //         alert("Failed to add appointment");
  //       }
  //     } catch (error) {
  //       console.error("Error adding appointment:", error);
  //       alert("An error occurred while adding the appointment");
  //     }
  //   }
  // };

  // useEffect(() => {
  //   if (state?.patient) {
  //     setLoading(true); // Start loading
  //     fetch(`${BASE_URL}/V1/patienttabs/otherTests/${state.patient.patient_id}`)
  //       .then((response) => {
  //         if (!response.ok) {
  //           throw new Error("Failed to fetch data");
  //         }
  //         return response.json();
  //       })
  //       .then((data) => {
  //         console.log("API Response:", data); // Log the API response
  //         if (data?.data) {
  //           // Check if data exists
  //           // Prefill the form with the fetched data
  //           setFormData({
  //             test_date: data.data.test_date || "", // Ensure this is correctly populated
  //             test_type: data.data.test_type || "",
  //             ref_doctor: data.data.ref_doctor || "",
  //             fee_status: data.data.fee_status || "",
  //             visit_type: data.data.visit_type || "",
  //             test_comment: data.data.test_comment || "",
  //           });
  //         }
  //       })
  //       .catch((error) => {
  //         console.error("Error fetching data:", error);
  //       })
  //       .finally(() => setLoading(false)); // Stop loading
  //   }
  // }, [state?.patient]); // Depend on the patient data to refetch when needed

  // Handle checkbox selection change for test type
  const handleTestTypeChange = (e, test_type) => {
    if (isDisabled) return; // Don't update if form is disabled

    const { checked } = e.target;
    setSelectedOptions((prevState) => {
      const updatedTestTypes = checked
        ? [...prevState.test_type, test_type]
        : prevState.test_type.filter((item) => item !== test_type);

      return {
        ...prevState,
        test_type: updatedTestTypes,
      };
    });
  };

  const fetchPreviousRecords = async (prevData) => {
    try {
      console.log("Fetching records for patientId:", patientId);

      if (!patientId) {
        console.error("No patientId available");
        alert("Patient ID is missing");
        return;
      }

      const response = await fetch(
        `${BASE_URL}/V1/otherTests/listOtherTests/${patientId}`
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error("API Error Response:", errorText);
        throw new Error(
          `Failed to fetch previous records: ${response.status} ${errorText}`
        );
      }

      const result = await response.json();
      console.log("Parsed API Response:", result);

      if (!result?.data?.otherTests) {
        console.log("No records found in response");
        alert("No previous records found.");
        return;
      }

      const otherTests = result.data.otherTests;
      console.log("Other Tests Data:", otherTests);

      // Set previous record date
      const recordDate = otherTests.test_date || "";
      console.log("Setting previous record date:", recordDate);
      setPreviousRecordDate(recordDate);

      // Disable the Previous Records button
      setDisablePreviousButton(true);

      // Show Edit button
      setShowEditButton(true);

      // Update form data with previous record matching the API structure
      const updatedFormData = {
        test_date: otherTests.test_date || "",
        ref_doctor: otherTests.ref_doctor || "",
        fee_status: otherTests.fee_status || "",
        visit_type: otherTests.visit_type || "",
        test_comment: otherTests.test_comment || "",
      };

      console.log("Updating form data with:", updatedFormData);
      setFormData(updatedFormData);

      // Reset selected options for test type
      setSelectedOptions((prev) => ({
        ...prev,
        test_type: [], // Reset to empty array
        ref_doctor: otherTests.ref_doctor || "",
      }));

      // Disable form editing until Edit button is clicked
      setIsDisabled(true);
    } catch (error) {
      console.error("Error in fetchPreviousRecords:", error);
      alert(`Failed to fetch previous records: ${error.message}`);
    }
  };

  // Add Edit button handler
  const handleEditOtherTests = () => {
    setIsDisabled(false);
    alert("Editing mode enabled. You can now modify the test details.");
  };

  const handleNewRecord = () => {
    // Clear form data
    setFormData({
      test_date: "",
      test_type: "",
      ref_doctor: "",
      fee_status: "",
      visit_type: "",
      test_comment: "",
    });

    // Reset selected options
    setSelectedOptions({
      test_type: [],
      ref_doctor: "",
    });

    // Enable the "Previous Records" button
    setDisablePreviousButton(false);

    // Hide the Edit button
    setShowEditButton(false);

    // Enable form editing
    setIsDisabled(false);

    // Clear previous record date
    setPreviousRecordDate("");

    alert("New Record: You can now enter new data.");
  };

  return (
    <div
      className="themebody-wrap"
      style={{
        background: "linear-gradient(to right, #e0f7fa, #80deea)",
        minHeight: "100vh",
        padding: "20px",
        fontFamily: "'Poppins', Arial, sans-serif",
      }}
    >
      <NavBarD pagename="Other Tests" />
      <Container fluid>
        <Row>
          <Col>
            <Card
              style={{
                borderRadius: "12px",
                boxShadow: "0px 6px 12px rgba(0, 0, 0, 0.15)",
                borderColor: "#00bcd4",
                background: "white",
                border: "1px solid #00bcd4",
              }}
            >
              <Card.Body>
                <Form>
                  <button
                    type="button"
                    className="btn btn-primary"
                    style={{ marginTop: "5px" }}
                    onClick={handleNewRecord}
                  >
                    New Record
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary"
                    style={{ marginTop: "5px", float: "right" }}
                    onClick={fetchPreviousRecords}
                    disabled={disablePreviousButton}
                  >
                    Previous Records
                  </button>
                  {/* Add Edit button */}
                  {showEditButton && (
                    <button
                      type="button"
                      className="btn btn-warning"
                      style={{
                        marginTop: "5px",
                        float: "right",
                        marginRight: "7px",
                      }}
                      onClick={handleEditOtherTests}
                    >
                      Edit Test Details
                    </button>
                  )}
                  <br />
                  <br />
                  {/* Show previous record date */}
                  {previousRecordDate && (
                    <div style={{ marginTop: "15px" }}>
                      <strong>Previous Record Date: </strong>
                      <span>{previousRecordDate}</span>
                    </div>
                  )}
                  <Row>
                    <Col md={4} className="mb-4">
                      <Form.Group className="mb-3">
                        <Form.Label>Date</Form.Label>
                        <Form.Control
                          type="date"
                          name="test_date"
                          value={formData.test_date || ""}
                          onChange={handleInputChange}
                          disabled={isDisabled}
                        />
                      </Form.Group>
                    </Col>

                    {/* Test Type Dropdown with Multiple Checkboxes */}
                    <Col md={4} className="mb-4">
                      <Form.Group controlId="test_type">
                        <Form.Label>Test Type</Form.Label>
                        <Dropdown>
                          <Dropdown.Toggle
                            variant="primary"
                            id="dropdown-basic"
                            disabled={isDisabled}
                          >
                            {selectedOptions.test_type.length === 0
                              ? "Select test types"
                              : selectedOptions.test_type.length === 1
                              ? selectedOptions.test_type[0]
                              : `${selectedOptions.test_type.length} Tests Selected`}
                          </Dropdown.Toggle>

                          <Dropdown.Menu
                            style={{
                              backgroundColor: "white",
                              padding: "10px",
                              maxHeight: "300px",
                              overflowY: "auto",
                            }}
                          >
                            {[
                              ...new Set([
                                ...tests.map((option) => option.test_type),
                                ...types.map((type) => type.name),
                              ]),
                            ].map((test_type, index) => (
                              <Form.Check
                                key={index}
                                type="checkbox"
                                label={test_type}
                                value={test_type}
                                checked={selectedOptions.test_type?.includes(
                                  test_type
                                )}
                                onChange={(e) =>
                                  handleTestTypeChange(e, test_type)
                                }
                              />
                            ))}
                          </Dropdown.Menu>
                        </Dropdown>
                        {/* Show selected items below only when multiple are selected */}
                        {selectedOptions.test_type.length > 1 && (
                          <div
                            className="mt-2"
                            style={{ fontSize: "0.9em", color: "#666" }}
                          ></div>
                        )}
                      </Form.Group>
                    </Col>

                    <Col md={4} className="mb-4">
                      <Form.Group controlId="ref_doctor">
                        <Form.Label>Ref. Doctor Name</Form.Label>
                        <Form.Select
                          value={selectedOptions?.ref_doctor || ""}
                          onChange={(e) =>
                            setSelectedOptions({
                              ...selectedOptions,
                              ref_doctor: e.target.value,
                            })
                          }
                          disabled={isDisabled}
                        >
                          <option value="">Assistant Doctor</option>
                          {[
                            ...new Set([
                              ...tests.map((option) => option.ref_doctor),
                              ...assistants.map((assistant) => assistant.name),
                            ]),
                          ].map((ref_doctor, index) => (
                            <option key={index} value={ref_doctor}>
                              {ref_doctor}
                            </option>
                          ))}
                        </Form.Select>
                      </Form.Group>
                    </Col>

                    <Col md={4} className="mb-4">
                      <Form.Group className="mb-3">
                        <Form.Label>Test Fee</Form.Label>
                        <Form.Select
                          name="fee_status"
                          value={formData.fee_status || ""}
                          onChange={handleInputChange}
                          disabled={isDisabled}
                        >
                          <option value="">SELECT FEE STATUS</option>
                          <option value="YES">YES</option>
                          <option value="NO">NO</option>
                          <option value="DUE">DUE</option>
                          <option value="DNC">DNC</option>
                        </Form.Select>
                      </Form.Group>
                    </Col>

                    <Col md={4} className="mb-4">
                      <Form.Group className="mb-3">
                        <Form.Label>Visit Type</Form.Label>
                        <Form.Select
                          name="visit_type"
                          value={formData.visit_type || ""}
                          onChange={handleInputChange}
                          disabled={isDisabled}
                        >
                          <option value="">SELECT VISIT TYPE</option>
                          <option value="OPD">OPD</option>
                          <option value="IPD">IPD</option>
                        </Form.Select>
                      </Form.Group>
                    </Col>

                    <Row>
                      <Col md={6} className="mb-4">
                        <Form.Group className="mb-3">
                          <Form.Label>Comment</Form.Label>
                          <Form.Control
                            as="textarea"
                            name="test_comment"
                            value={formData.test_comment || ""}
                            onChange={handleInputChange}
                            placeholder="Enter Comments"
                            disabled={isDisabled}
                          />
                        </Form.Group>
                      </Col>
                    </Row>

                    <button
                      type="button"
                      className="btn btn-primary"
                      style={{ marginTop: "30px" }}
                      onClick={handleSubmit}
                    >
                      Submit
                    </button>
                  </Row>
                </Form>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}
