import { useState, useEffect } from "react";
import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Container,
  Tab,
  Tabs,
} from "react-bootstrap";
import NavBarD from "./NavbarD";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const BASE_URL = "http://192.168.90.210:5000/api";

const SurgeryTabs = ({
  selectedOptions,
  setSelectedOptions,
  isDisabled,
  formData,
  setFormData,
}) => {
  const [key, setKey] = useState("piles");

  // Ensure formData and surgeryTabs exist
  if (!formData || !formData.surgeryTabs) {
    return null; // Or a loading state
  }

  const tabData = [
    {
      id: "piles",
      title: "Piles",
      checkboxes: [
        "PR Bleeding: Painless",
        "PR Bleeding: Painful",
        "Burning",
        "Pricking",
        "Itching",
        "Incomplete Evacuation",
        "Prolapse",
        "Swelling",
        "Pain at Anal Region",
        "Mucus Mixed Blood",
      ],
      textarea: "piles_duration",
    },
    {
      id: "fistula",
      title: "Fistula",
      checkboxes: [
        "Pus Discharge",
        "Boil",
        "Watery Discharge",
        "Swelling near anal region",
        "Discharge from vagina gases/ stool",
      ],
      textarea: "fistula_duration",
    },
    {
      id: "hernia",
      title: "Hernia",
      checkboxes: [
        "Swelling: Umbilical",
        "Right Inguinal",
        "Left Inguinal",
        "Swelling: Abdominal",
        "Reducible",
        "Nonreducible",
        "Past Sx",
      ],
      textarea: "hernia_duration",
    },
    {
      id: "varicose",
      title: "Varicose",
      checkboxes: ["Varicose Veins"],
      textarea: "varicose_duration",
    },
    {
      id: "uninary",
      title: "Uninary",
      checkboxes: ["Uninary Incontinence"],
      textarea: "Urinary_incontinence_duration",
    },
    {
      id: "fecal",
      title: "Fecal",
      checkboxes: ["Fecal Incontinence"],
      textarea: "Fecal_incontinence_duration",
    },
    {
      id: "urology",
      title: "Urology",
      checkboxes: [
        "Pain",
        "Burning urination",
        "Nausea",
        "Vomiting",
        "LUTS",
        "Urgency of urination",
        "Incomplete evacuation",
        "Stream of urine",
        "Nocturia",
      ],
    },
    {
      id: "ods",
      title: "ODS",
      checkboxes: [
        "Excessive Straining",
        "Digitation",
        "Hard Stools",
        "Enema/laxative",
        "Fragmented Defecation",
      ],
      textareas: [
        { name: "ods_duration", placeholder: "Duration" },
        { name: "bowel_habits", placeholder: "Bowel Habits" },
      ],
    },
    {
      id: "pilonidal",
      title: "Pilonidal Sinus",
      checkboxes: [], // No checkboxes for this tab
      textarea: "pilonidalsinus",
    },
    {
      id: "circumcision",
      title: "Circumcision",
      checkboxes: [], // No checkboxes for this tab
      textarea: "circumcision",
    },
  ];

  const handleCheckboxChange = (e) => {
    const { value, checked } = e.target;
    setSelectedOptions((prev) =>
      checked ? [...prev, value] : prev.filter((item) => item !== value)
    );
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      surgeryTabs: {
        ...prevState.surgeryTabs,
        [name]: value,
      },
    }));
  };

  return (
    <Tabs
      activeKey={key}
      onSelect={(k) => setKey(k)}
      style={{ borderBottom: "2px solid #e0f7fa" }}
    >
      {tabData.map((tab) => (
        <Tab
          eventKey={tab.id}
          title={tab.title}
          key={tab.id}
          style={{ padding: "15px" }}
        >
          <Row>
            {tab.checkboxes.map((item, index) => (
              <Col md={4} key={index} style={{ marginBottom: "10px" }}>
                <Form.Check
                  type="checkbox"
                  id={`${tab.id}-${index}`}
                  label={item}
                  value={item}
                  checked={selectedOptions?.includes(item)}
                  onChange={handleCheckboxChange}
                  disabled={isDisabled}
                />
              </Col>
            ))}
          </Row>

          {tab.textarea && (
            <Row style={{ marginTop: "20px" }}>
              <Col md={6}>
                <Form.Control
                  as="textarea"
                  name={tab.textarea}
                  placeholder="Duration"
                  value={formData.surgeryTabs[tab.textarea] || ""}
                  onChange={handleInputChange}
                  disabled={isDisabled}
                  style={{
                    width: "100%",
                    minHeight: "80px",
                    padding: "10px",
                    borderRadius: "4px",
                    border: "1px solid #ced4da",
                  }}
                />
              </Col>
            </Row>
          )}
        </Tab>
      ))}
    </Tabs>
  );
};

export default function PatientHistory() {
  const [patientId, setPatientId] = useState(
    localStorage.getItem("selectedPatientId")
  );
  const [showTextareas, setShowTextareas] = useState({}); // Track visibility of textareas
  const [selectedFile, setSelectedFile] = useState(null);
  const [formData, setFormData] = useState({
    patient_date: "",
    height: "",
    weight: "",
    painScale: "",
    vitalSigns: {
      BP: "",
      Pulse: "",
      RR: "",
    },
    systematicExamination: {
      RS: "",
      CVS: "",
      CNS: "",
      PA: "",
    },
    general_history: {
      hoWtLoss: false,
      decAppetite: false,
      hoStrainingForurination: false,
      acidity: false,
      gas: false,
      bloating: false,
    },
    family_history: {
      piles: false,
      constipation: false,
      dm: false,
      htn: false,
      heartDisease: false,
      other: "",
    },
    past_history: {
      dm: "",
      htn: "",
      brAsthma: "",
      thyroid: "",
    },
    habits: {
      smoking: "",
      alcohol: "",
      tobacco: "",
      drugs: "",
    },
    drugs_allergy: "",
    pastSurgicalHistory: "",
    anyOtherComplaints: "",
    presentComplaints: "",
    ongoing_medicines: {
      Clopidogrel: false,
      aspirin: false,
      warfarin: false,
    },
    otherongoingmedi: "",
    investigation: {
      hb: false,
      bslr: false,
      bleedingTimeBt: false,
      clottingTimeBt: false,
      ptInr: false,
      hiv: false,
      hbsag: false,
      srCreatinine: false,
      vitB: false,
    },
    knowncaseof: "",
    advice: {
      mrd: false,
      manoBf: false,
      coloGastro: false,
      diet: false,
      b: false,
      d: false,
    },
    medications: [
      { id: 1, name: "", indication: "", since: "" },
      { id: 2, name: "", indication: "", since: "" },
    ],
    surgeryTabs: {
      piles_duration: "",
      fistula_duration: "",
      hernia_duration: "",
      varicose_duration: "",
      uninary_duration: "",
      fecal_duration: "",
      urology_duration: "",
      ods_duration: "",
      bowel_habits: "",
      pilonidalsinus: "",
      circumcision: "",
    },
  });

  const [errors, setErrors] = useState({});
  const [patientHistory, setPatientHistory] = useState([]);
  const [assistantsDoctor, setAssistantsDoctor] = useState([]);
  const [showEditButton, setShowEditButton] = useState(false); // Controls visibility of "Edit Diagnosis"
  const [isDisabled, setIsDisabled] = useState(false); // Controls edit mode
  const [disablePreviousButton, setDisablePreviousButton] = useState(false); // Disables "Previous Records" after clicking
  const [selectedOptions, setSelectedOptions] = useState([]); // Track selected checkboxes

  useEffect(() => {
    const storedPatientId = localStorage.getItem("selectedPatientId");
    console.log("Retrieved from localStorage:", storedPatientId);
    if (storedPatientId) setPatientId(storedPatientId);
  }, []);

  useEffect(() => {
    if (!patientId) {
      console.warn("No patientId found, skipping fetch");
      return;
    }
    const fetchPatientData = async () => {
      console.log(`Fetching data for patient ID: ${patientId}`);
      try {
        const response = await fetch(
          `${BASE_URL}/V1/patientHistory/listPatientHistory/${patientId}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        if (!response.ok) {
          console.error(
            "API Response Error:",
            response.status,
            await response.text()
          );
          return;
        }

        const data = await response.json();
        console.log("Fetched Data:", data);

        if (data?.data?.patientHistory?.length > 0) {
          const patientData = data.data.patientHistory[0];

          // Safely update formData with nested objects
          setFormData((prevState) => ({
            ...prevState,
            ...patientData,
            vitalSigns: {
              ...prevState.vitalSigns,
              ...(patientData.vitalSigns || {}),
            },
            systematicExamination: {
              ...prevState.systematicExamination,
              ...(patientData.systematicExamination || {}),
            },
            general_history: {
              ...prevState.general_history,
              ...(patientData.general_history || {}),
            },
            family_history: {
              ...prevState.family_history,
              ...(patientData.family_history || {}),
            },
            past_history: {
              ...prevState.past_history,
              ...(patientData.past_history || {}),
            },
            habits: {
              ...prevState.habits,
              ...(patientData.habits || {}),
            },
            ongoing_medicines: {
              ...prevState.ongoing_medicines,
              ...(patientData.ongoing_medicines || {}),
            },
            investigation: {
              ...prevState.investigation,
              ...(patientData.investigation || {}),
            },
            advice: {
              ...prevState.advice,
              ...(patientData.advice || {}),
            },
            knowncaseof: {
              ...prevState.knowncaseof,
              ...(patientData.knowncaseof || {}),
            },
            medications: patientData.medications || prevState.medications,
          }));
        } else {
          console.warn("No patient data found in API response");
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchPatientData();
  }, [patientId]);

  // Fetch options from API
  useEffect(() => {
    const fetchDropdownOptions = async () => {
      try {
        const endpoints = [
          {
            url: "/V1/patienttabsdp/assistantDoc_dropdown",
            setter: setAssistantsDoctor,
          },
        ];

        for (const { url, setter } of endpoints) {
          const response = await fetch(`${BASE_URL}${url}`);
          const data = await response.json();
          if (response.ok) setter(data.data || []);
        }
      } catch (err) {
        setErrors("Failed to fetch dropdown data.");
      }
    };
    fetchDropdownOptions();
  }, [patientId]);

  const validate = () => {
    const validationErrors = {};
    if (!formData.patient_date)
      validationErrors.patient_date = "Patient date is required";
    if (!formData.height) validationErrors.height = "Height is required";
    if (!formData.weight) validationErrors.weight = "Weight is required";
    return validationErrors;
  };

  const handleInputChange = (e, id, field) => {
    const { name, value, type, checked } = e.target;

    if (name === "family_history") {
      setFormData((prevState) => ({
        ...prevState,
        family_history: {
          ...prevState.family_history,
          other: value,
        },
      }));
    } else {
      setFormData((prevState) => ({
        ...prevState,
        [name]: type === "checkbox" ? checked : value,
      }));
    }
    if (id && field) {
      // Medication update
      const updatedMedications = formData.medications.map((med) =>
        med.id === id ? { ...med, [field]: value } : med
      );
      setFormData({ ...formData, medications: updatedMedications });
    } else {
      // General form field update
      setFormData({ ...formData, [name]: value });
    }
  };

  // Handle File Selection
  const handleFileChange = (event) => {
    const file = event.target.files[0]; // Get the selected file
    setSelectedFile(file);
  };

  const handleCheckboxChange = (e) => {
    const { name, checked } = e.target;
    const [category, field] = name.split(".");
    const [parent, child] = name.split(".");

    if (name === "family_history") {
      setFormData((prevState) => ({
        ...prevState,
        family_history: {
          ...prevState.family_history,
          [child]: checked,
        },
      }));
    } else if (child) {
      setFormData({
        ...formData,
        [parent]: { ...formData[parent], [child]: checked },
      });
    } else {
      setFormData((prev) => ({
        ...prev,
        [category]: {
          ...prev[category],
          [field]: checked,
        },
      }));
    }
  };

  const handleHistoryClick = async () => {
    const patientId = localStorage.getItem("selectedPatientId");

    try {
      console.log("Form data before saving:", formData);
      // Format the data before sending
      const formattedData = {
        ...formData,
        // Convert objects to strings using JSON.stringify
        general_history: JSON.stringify(formData.general_history),
        past_history: JSON.stringify(formData.past_history),
        habits: JSON.stringify(formData.habits),
        ongoing_medicines: JSON.stringify(formData.ongoing_medicines),
        investigation: JSON.stringify(formData.investigation),
        vitalSigns: JSON.stringify(formData.vitalSigns),
        systematicExamination: JSON.stringify(formData.systematicExamination),
        family_history: JSON.stringify(formData.family_history),
        advice: JSON.stringify(formData.advice),
        selectedOptions,
        patientId,
      };

      // First, save the patient history data
      const saveResponse = await fetch(
        `${BASE_URL}/V1/patientHistory/addPatientHistory/${patientId}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formattedData),
        }
      );

      if (!saveResponse.ok) {
        const errorData = await saveResponse.json();
        throw new Error(errorData.message || "Failed to save patient history");
      }

      // Then, update the historychk
      const historyResponse = await fetch(
        `${BASE_URL}/V1/patientHistory/updateHistoryChk/${patientId}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ historychk: 3 }),
        }
      );

      if (!historyResponse.ok) {
        throw new Error("Failed to update history check");
      }

      // If both operations are successful, show success message
      alert("Patient history saved successfully!");
    } catch (error) {
      console.error("Error saving patient history:", error);
      alert("Failed to save patient history. Please try again.");
    }
  };
  const [previousRecordDate, setPreviousRecordDate] = useState(""); // Store the previous record date

  const fetchPreviousRecords = async (prevData) => {
    try {
      console.log("Fetching previous records for patientId:", patientId);

      const response = await fetch(
        `${BASE_URL}/V1/patientHistory/listPatientHistory/${patientId}`
      );

      const result = await response.json();
      console.log("on click Fetched Data:", result.data.patientHistory); // Log API response

      if (!response.ok) {
        throw new Error("Failed to fetch previous records");
      }

      const patientHistory = result.data.patientHistory;

      // Set previous record date before updating formData
      setPreviousRecordDate(
        patientHistory.date_patientHistory || prevData.date_patientHistory || ""
      );
      const symptomsArray = patientHistory.symptoms;

      // Update formData with all the fields from the API
      setFormData((prevData) => ({
        ...prevData,
        // Basic details
        patient_date: patientHistory.patient_date || "",
        height: patientHistory.height || "",
        weight: patientHistory.weight || "",
        painScale: patientHistory.painScale || "",

        // Vital Signs
        vitalSigns: {
          ...prevData.vitalSigns,
          BP: patientHistory.BP || "",
          Pulse: patientHistory.Pulse || "",
          RR: patientHistory.RR || "",
        },

        // Systematic Examination
        systematicExamination: {
          ...prevData.systematicExamination,
          RS: patientHistory.RS || "",
          CVS: patientHistory.CVS || "",
          CNS: patientHistory.CNS || "",
          PA: patientHistory.PA || "",
        },

        // General History
        general_history: {
          ...prevData.general_history,
          hoWtLoss: patientHistory.hoWtLoss || false,
          decAppetite: patientHistory.decAppetite || false,
          hoStrainingForurination:
            patientHistory.hoStrainingForurination || false,
          acidity: patientHistory.acidity || false,
          gas: patientHistory.gas || false,
          bloating: patientHistory.bloating || false,
        },

        // Symptoms checkboxes (based on the symptoms string)
        symptoms: {
          ...prevData.symptoms,
          pusDischarge: symptomsArray.includes("Pus Discharge"),
          boil: symptomsArray.includes("Boil"),
          wateryDischarge: symptomsArray.includes("Watery Discharge"),
          swellingAnalRegion: symptomsArray.includes(
            "Swelling near anal region"
          ),
        },

        // Family History checkboxes
        family_history: {
          ...prevData.family_history,
          piles: Boolean(patientHistory.family_history?.includes("Piles")),
          constipation: Boolean(
            patientHistory.family_history?.includes("Constipation")
          ),
          dm: Boolean(patientHistory.family_history?.includes("DM")),
          htn: Boolean(patientHistory.family_history?.includes("HTN")),
          heartDisease: Boolean(
            patientHistory.family_history?.includes("Heart Disease")
          ),
          other: patientHistory.family_history || "",
        },

        // Past History
        past_history: {
          ...prevData.past_history,
          dm: patientHistory.dm || "",
          htn: patientHistory.htn || "",
          brAsthma: patientHistory.brAsthma || "",
          thyroid: patientHistory.thyroid || "",
        },

        // Habits checkboxes
        habits: {
          ...prevData.habits,
          smoking: Boolean(patientHistory.habits?.includes("Smoking")),
          alcohol: Boolean(patientHistory.habits?.includes("Alcohol")),
          tobacco: Boolean(patientHistory.habits?.includes("Tobacco")),
          drugs: Boolean(patientHistory.habits?.includes("Drugs")),
        },

        surgeryTabs: {
          ...prevData.surgeryTabs,
          piles_duration: patientHistory.piles_duration || "",
          fistula_duration: patientHistory.fistula_duration || "",
          hernia_duration: patientHistory.hernia_duration || "",
          varicose_duration: patientHistory.varicose_duration || "",
        },

        // Surgery Tabs Data
        piles: patientHistory.piles || [],
        fistula: patientHistory.fistula || [],
        hernia: patientHistory.hernia || [],
        varicose: patientHistory.varicose || [],
        uninary: patientHistory.uninary || [],
        fecal: patientHistory.fecal || [],
        urology: patientHistory.urology || [],
        ods: patientHistory.ods || [],
        pilonidal: patientHistory.pilonidal || "",
        circumcision: patientHistory.circumcision || "",

        // Other fields
        drugs_allergy: patientHistory.drugs_allergy || "",
        pastSurgicalHistory: patientHistory.pastSurgicalHistory || "",
        anyOtherComplaints: patientHistory.anyOtherComplaints || "",
        presentComplaints: patientHistory.presentComplaints || "",

        // Ongoing Medicines checkboxes
        ongoing_medicines: {
          ...prevData.ongoing_medicines,
          Clopidogrel: Boolean(
            patientHistory.medication_on?.includes("Clopidogrel")
          ),
          aspirin: Boolean(patientHistory.medication_on?.includes("Aspirin")),
          warfarin: Boolean(patientHistory.medication_on?.includes("Warfarin")),
        },

        otherongoingmedi: patientHistory.otherongoingmedi || "",

        // Investigation checkboxes
        investigation: {
          ...prevData.investigation,
          hb: Boolean(patientHistory.investigation?.includes("HB")),
          bslr: Boolean(patientHistory.investigation?.includes("BSLR")),
          bleedingTimeBt: Boolean(patientHistory.investigation?.includes("BT")),
          clottingTimeBt: Boolean(patientHistory.investigation?.includes("CT")),
          ptInr: Boolean(patientHistory.investigation?.includes("PT/INR")),
          hiv: Boolean(patientHistory.investigation?.includes("HIV")),
          hbsag: Boolean(patientHistory.investigation?.includes("HBsAg")),
          srCreatinine: Boolean(
            patientHistory.investigation?.includes("Sr. Creatinine")
          ),
          vitB: Boolean(patientHistory.investigation?.includes("Vit B12")),
        },
        investigationComments: patientHistory.investigationComments || {},
        knowncaseof: patientHistory.knowncaseof || "",

        // Advice
        advice: {
          ...prevData.advice,
          mrd: patientHistory.mrd || false,
          manoBf: patientHistory.manoBf || false,
          coloGastro: patientHistory.coloGastro || false,
          diet: patientHistory.diet || false,
          b: patientHistory.b || false,
          d: patientHistory.d || false,
        },

        // Medications
        medications: patientHistory.medications || [
          { id: 1, name: "", indication: "", since: "" },
          { id: 2, name: "", indication: "", since: "" },
        ],
      }));
      // Add debug logging
      console.log("Parsed symptoms:", symptomsArray);
      console.log("Updated form data:", formData);

      // Also update selected checkboxes for surgery tabs
      setSelectedOptions(patientHistory.selectedOptions || []);

      // Show the "Edit Diagnosis" button
      setShowEditButton(true);
      // Disable "Previous Records" button after clicking it
      setDisablePreviousButton(true);
      // Disable form fields
      setIsDisabled(true);

      console.log("Form data updated with previous records");
    } catch (error) {
      console.error("Error fetching previous records:", error);
      alert("Failed to fetch previous records.");
    }
  };

  // // Updated safeJSONParse function with better error handling
  // const safeJSONParse = (jsonString, defaultValue) => {
  //   if (!jsonString) return defaultValue;
  //   try {
  //     const parsed = JSON.parse(jsonString);
  //     return parsed || defaultValue;
  //   } catch (error) {
  //     console.warn("JSON Parse error:", error);
  //     return defaultValue;
  //   }
  // };

  // Enable form editing when "Edit Diagnosis" is clicked
  const handleEditPatientHistory = () => {
    setIsDisabled(false);
    alert("Editing mode enabled. You can now modify the diagnosis details.");
  };

  const handleNewRecord = () => {
    const newData = {
      patient_date: new Date().toISOString().split("T")[0],
      height: "",
      weight: "",
      painScale: "",

      vitalSigns: { BP: "", Pulse: "", RR: "" },
      systematicExamination: { RS: "", CVS: "", CNS: "", PA: "" },
      general_history: {
        hoWtLoss: false,
        decAppetite: false,
        hoStrainingForurination: false,
        acidity: false,
        gas: false,
        bloating: false,
      },
      family_history: {
        piles: false,
        constipation: false,
        dm: false,
        htn: false,
        heartDisease: false,
        other: "",
      },
      past_history: { dm: "", htn: "", brAsthma: "", thyroid: "" },
      habits: { smoking: "", alcohol: "", tobacco: "", drugs: "" },
      piles: [],
      fistula: [],
      hernia: [],
      varicose: [],
      uninary: [],
      fecal: [],
      urology: [],
      ods: [],
      pilonidal: "",
      circumcision: "",
      drugs_allergy: "",
      pastSurgicalHistory: "",
      anyOtherComplaints: "",
      presentComplaints: "",
      ongoing_medicines: {
        Clopidogrel: false,
        aspirin: false,
        warfarin: false,
      },
      otherongoingmedi: "",
      investigation: {
        hb: false,
        bslr: false,
        bleedingTimeBt: false,
        clottingTimeBt: false,
        ptInr: false,
        hiv: false,
        hbsag: false,
        srCreatinine: false,
        vitB: false,
      },
      knowncaseof: "",
      advice: {
        mrd: false,
        manoBf: false,
        coloGastro: false,
        diet: false,
        b: false,
        d: false,
      },
      medications: [
        { id: 1, name: "", indication: "", since: "" },
        { id: 2, name: "", indication: "", since: "" },
      ],
      surgeryTabs: {
        piles_duration: "",
        fistula_duration: "",
        hernia_duration: "",
        varicose_duration: "",
        uninary_duration: "",
        fecal_duration: "",
        urology_duration: "",
        ods_duration: "",
        bowel_habits: "",
        pilonidal_sinus: "",
      },
    };

    console.log("New Form Data:", newData);
    setFormData(newData);

    // Reset other states
    setSelectedOptions([]);
    setShowEditButton(false);
    setDisablePreviousButton(false);
    setIsDisabled(false);

    alert("New Record: You can now enter new data.");
  };

  return (
    <div
      className="themebody-wrap"
      style={{
        background: "linear-gradient(to right, #e0f7fa, #80deea)",
        minHeight: "100vh",
        padding: "20px",
        fontFamily: "'Poppins', Arial, sans-serif",
      }}
    >
      <NavBarD pagename="Patient History" />

      <Container fluid>
        <Row>
          <Col>
            <Card
              style={{
                borderRadius: "12px",
                boxShadow: "0px 6px 12px rgba(0, 0, 0, 0.15)",
                borderColor: "#00bcd4",
                background: "#f8f9fa",
                border: "3px solid #00bcd4",
              }}
            >
              <Card.Body>
                <Form>
                  <div>
                    <button
                      type="button"
                      className="btn btn-primary"
                      style={{ marginRight: "20px" }}
                      onClick={handleNewRecord}
                    >
                      New Record
                    </button>
                    <button
                      type="button"
                      className="btn btn-primary"
                      style={{
                        float: "right",
                      }}
                      onClick={fetchPreviousRecords}
                      disabled={disablePreviousButton}
                    >
                      Previous Records
                    </button>
                    {/* Show Edit Diagnosis Button only after clicking "Previous Records" */}
                    {showEditButton && (
                      <button
                        type="button"
                        className="btn btn-warning"
                        style={{ float: "right", marginRight: "7px" }}
                        onClick={handleEditPatientHistory}
                      >
                        Edit Diagnosis
                      </button>
                    )}
                  </div>
                  {/* Show the previous record date when available */}
                  {previousRecordDate && (
                    <div style={{ marginTop: "15px" }}>
                      <strong>Previous Record Date: </strong>
                      <span>{previousRecordDate}</span>
                    </div>
                  )}
                  <br />
                  {/* Row 1: Patient Info */}
                  <Row>
                    <Col md={2} className="mb-4">
                      <Form.Group className="mb-3">
                        <Form.Label>Patient Date:</Form.Label>
                        <DatePicker
                          selected={
                            formData?.patient_date
                              ? new Date(formData.patient_date)
                              : null
                          }
                          onChange={(date) => {
                            handleInputChange({
                              target: {
                                name: "patient_date",
                                value: date
                                  ? date.toISOString().split("T")[0]
                                  : "",
                              },
                            });
                          }}
                          isInvalid={!!errors.patientDate}
                          dateFormat="yyyy-MM-dd"
                          className="form-control"
                          placeholderText="Select Patient Date"
                          maxDate={new Date()}
                          showMonthDropdown
                          showYearDropdown
                          dropdownMode="select"
                        />
                        <Form.Control.Feedback type="invalid">
                          {errors.patientDate}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>

                    <Col md={2} className="mb-4">
                      <Form.Group>
                        <Form.Label>Height:</Form.Label>
                        <div className="d-flex">
                          <Form.Control
                            type="number"
                            name="height"
                            value={formData.height}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                height: e.target.value,
                              })
                            }
                            isInvalid={!!errors.height}
                            placeholder="Enter height"
                          />
                          <span className="ms-2 align-self-center">FEET</span>{" "}
                          {/* Text outside the box */}
                        </div>
                        <Form.Control.Feedback type="invalid">
                          {errors.height}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                    <Col md={2} className="mb-4">
                      <Form.Group>
                        <Form.Label>Weight:</Form.Label>
                        <div className="d-flex">
                          <Form.Control
                            type="number"
                            name="weight"
                            value={formData.weight}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                weight: e.target.value,
                              })
                            }
                            isInvalid={!!errors.weight}
                            placeholder="Enter weight"
                          />
                          <span className="ms-2 align-self-center">kgs</span>{" "}
                          {/* Text outside the box */}
                        </div>
                        <Form.Control.Feedback type="invalid">
                          {errors.weight}
                        </Form.Control.Feedback>
                      </Form.Group>
                    </Col>
                  </Row>
                  <br />
                  <SurgeryTabs
                    selectedOptions={selectedOptions}
                    setSelectedOptions={setSelectedOptions}
                    isDisabled={isDisabled}
                    formData={formData}
                    setFormData={setFormData}
                  />
                  <Row>
                    <Col md={3}>
                      <Form.Group>
                        <Form.Label>Pain Score:</Form.Label>
                        <Form.Select
                          as="select"
                          name="painScale"
                          value={formData.painScale}
                          onChange={handleInputChange}
                        >
                          <option value="" disabled>
                            Select Pain Score
                          </option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="4">4</option>
                          <option value="5">5</option>
                          <option value="6">6</option>
                          <option value="7">7</option>
                          <option value="8">8</option>
                          <option value="9">9</option>
                          <option value="10">10</option>
                        </Form.Select>
                      </Form.Group>
                    </Col>
                  </Row>
                  <br />
                  <Row>
                    <Col md={6}>
                      {/* Row 3: Vital Signs */}
                      <Form.Label>Vital Signs:</Form.Label>
                      <Row>
                        <Col md={3}>
                          <Form.Group>
                            <Form.Label>BP:</Form.Label>
                            <div className="d-flex align-items-center">
                              <Form.Control
                                type="text"
                                name="vitalSigns.BP"
                                value={formData.vitalSigns.BP}
                                onChange={(e) => {
                                  const value = e.target.value.replace(
                                    /\D/g,
                                    ""
                                  ); // Allow only numbers
                                  setFormData((prev) => ({
                                    ...prev,
                                    vitalSigns: {
                                      ...prev.vitalSigns,
                                      BP: value,
                                    },
                                  }));
                                }}
                              />
                              <span className="ms-2">mm of hg</span>
                            </div>
                          </Form.Group>
                        </Col>
                        <Col md={3}>
                          <Form.Group>
                            <Form.Label>Pulse:</Form.Label>
                            <div className="d-flex align-items-center">
                              <Form.Control
                                type="text"
                                name="vitalSigns.Pulse"
                                value={formData.vitalSigns.Pulse}
                                onChange={(e) => {
                                  const value = e.target.value.replace(
                                    /\D/g,
                                    ""
                                  );
                                  setFormData((prev) => ({
                                    ...prev,
                                    vitalSigns: {
                                      ...prev.vitalSigns,
                                      Pulse: value,
                                    },
                                  }));
                                }}
                              />
                              <span className="ms-2">/Min</span>
                            </div>
                          </Form.Group>
                        </Col>
                        <Col md={3}>
                          <Form.Group>
                            <Form.Label>RR:</Form.Label>
                            <div className="d-flex align-items-center">
                              <Form.Control
                                type="text"
                                name="vitalSigns.RR"
                                value={formData.vitalSigns.RR}
                                onChange={(e) => {
                                  const value = e.target.value.replace(
                                    /\D/g,
                                    ""
                                  );
                                  setFormData((prev) => ({
                                    ...prev,
                                    vitalSigns: {
                                      ...prev.vitalSigns,
                                      RR: value,
                                    },
                                  }));
                                }}
                              />
                              <span className="ms-2">/Min</span>
                            </div>
                          </Form.Group>
                        </Col>
                      </Row>
                    </Col>
                    <Col md={6}>
                      <Form.Label>Systematic Examination:</Form.Label>
                      <Row>
                        <Col md={2}>
                          <Form.Group>
                            <Form.Label>RS:</Form.Label>
                            <div className="d-flex align-items-center">
                              <Form.Control
                                type="text"
                                name="systematicExamination.RS"
                                value={formData.systematicExamination.RS}
                                onChange={(e) =>
                                  setFormData((prev) => ({
                                    ...prev,
                                    systematicExamination: {
                                      ...prev.systematicExamination,
                                      RS: e.target.value,
                                    },
                                  }))
                                }
                              />
                            </div>
                          </Form.Group>
                        </Col>
                        <Col md={2}>
                          <Form.Group>
                            <Form.Label>CVS:</Form.Label>
                            <Form.Control
                              type="text"
                              name="systematicExamination.CVS"
                              value={formData.systematicExamination.CVS}
                              onChange={(e) =>
                                setFormData((prev) => ({
                                  ...prev,
                                  systematicExamination: {
                                    ...prev.systematicExamination,
                                    CVS: e.target.value,
                                  },
                                }))
                              }
                            />
                          </Form.Group>
                        </Col>
                        <Col md={2}>
                          <Form.Group>
                            <Form.Label>CNS:</Form.Label>
                            <Form.Control
                              type="text"
                              name="systematicExamination.CNS"
                              value={formData.systematicExamination.CNS}
                              onChange={(e) =>
                                setFormData((prev) => ({
                                  ...prev,
                                  systematicExamination: {
                                    ...prev.systematicExamination,
                                    CNS: e.target.value,
                                  },
                                }))
                              }
                            />
                          </Form.Group>
                        </Col>
                        <Col md={2}>
                          <Form.Group>
                            <Form.Label>P/A:</Form.Label>
                            <Form.Control
                              type="text"
                              name="systematicExamination.PA"
                              value={formData.systematicExamination.PA}
                              onChange={(e) =>
                                setFormData((prev) => ({
                                  ...prev,
                                  systematicExamination: {
                                    ...prev.systematicExamination,
                                    PA: e.target.value,
                                  },
                                }))
                              }
                            />
                          </Form.Group>
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  {/* Row 5: Family History */}
                  <Row className="mb-3">
                    <Col>
                      <Form.Group>
                        <Form.Label>Family History:</Form.Label>
                        <div>
                          <Form.Check
                            inline
                            label="Piles"
                            name="family_history.piles"
                            checked={formData.family_history.piles}
                            onChange={handleCheckboxChange}
                          />
                          <Form.Check
                            inline
                            label="Constipation"
                            name="family_history.constipation"
                            checked={formData.family_history.constipation}
                            onChange={handleCheckboxChange}
                          />
                          <Form.Check
                            inline
                            label="DM"
                            name="family_history.dm"
                            checked={formData.family_history.dm}
                            onChange={handleCheckboxChange}
                          />
                          <Form.Check
                            inline
                            label="HTN"
                            name="family_history.htn"
                            checked={formData.family_history.htn}
                            onChange={handleCheckboxChange}
                          />
                          <Form.Check
                            inline
                            label="Heart Disease"
                            name="family_history.heartDisease"
                            checked={formData.family_history.heartDisease}
                            onChange={handleCheckboxChange}
                          />
                          <Col xs={7}>
                            <Form.Control
                              as="textarea"
                              placeholder="Other"
                              name="family_history"
                              value={formData.family_history?.other}
                              onChange={handleInputChange}
                            />
                          </Col>
                        </div>
                      </Form.Group>
                    </Col>
                  </Row>
                  <br />
                  {/* Row 6: General History */}
                  <Row className="mb-3">
                    <Col>
                      <Form.Group>
                        <Form.Label>General History:</Form.Label>
                        <div>
                          <Form.Check
                            inline
                            label="H/o Wt Loss"
                            name="general_history.hoWtLoss"
                            checked={formData.general_history.hoWtLoss}
                            onChange={handleCheckboxChange}
                          />
                          <Form.Check
                            inline
                            label="Dec Appetite"
                            name="general_history.decAppetite"
                            checked={formData.general_history.decAppetite}
                            onChange={handleCheckboxChange}
                          />
                          <Form.Check
                            inline
                            label="H/O Straining for urination"
                            name="general_history.hoStrainingForurination"
                            checked={
                              formData.general_history.hoStrainingForurination
                            }
                            onChange={handleCheckboxChange}
                          />
                          <Form.Check
                            inline
                            label="Acidity"
                            name="general_history.acidity"
                            checked={formData.general_history.acidity}
                            onChange={handleCheckboxChange}
                          />
                          <Form.Check
                            inline
                            label="Bloating"
                            name="general_history.bloating"
                            checked={formData.general_history.bloating}
                            onChange={handleCheckboxChange}
                          />
                          <Form.Check
                            inline
                            label="Gas"
                            name="general_history.gas"
                            checked={formData.general_history.gas}
                            onChange={handleCheckboxChange}
                          />
                        </div>
                      </Form.Group>
                    </Col>
                  </Row>
                  <br />
                  <Row className="mb-3">
                    <Form.Label>Past Medical History:</Form.Label>
                    <Col>
                      <Form.Group>
                        <Form.Check
                          inline
                          type="checkbox"
                          label="DM"
                          name="past_history.dm"
                          checked={formData.past_history.dm}
                          onChange={handleCheckboxChange}
                        />
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group>
                        <Form.Check
                          inline
                          type="checkbox"
                          label="HTN"
                          name="past_history.htn"
                          checked={formData.past_history.htn}
                          onChange={handleCheckboxChange}
                        />
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group>
                        <Form.Check
                          inline
                          type="checkbox"
                          label="Br Asthma"
                          name="past_history.brAsthma"
                          checked={formData.past_history.brAsthma}
                          onChange={handleCheckboxChange}
                        />
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group>
                        <Form.Check
                          inline
                          type="checkbox"
                          label="Thyroid"
                          name="past_history.thyroid"
                          checked={formData.past_history.thyroid}
                          onChange={handleCheckboxChange}
                        />
                      </Form.Group>
                    </Col>
                  </Row>
                  <Row>
                    <Col md={6}>
                      <Form.Control
                        as="textarea"
                        placeholder="Any Other Specify"
                        name="past_history.otherDetails"
                        value={formData.past_history.otherDetails || ""}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            past_history: {
                              ...prev.past_history,
                              otherDetails: e.target.value,
                            },
                          }))
                        }
                        style={{ minHeight: "80px" }}
                      />
                    </Col>
                  </Row>
                  <Form.Label>Habits:</Form.Label>
                  <Row className="mb-3">
                    <Col>
                      <Form.Group>
                        <Form.Check
                          inline
                          type="checkbox"
                          label="Smoking"
                          name="habits.smoking"
                          checked={formData.habits.smoking}
                          onChange={handleCheckboxChange}
                        />
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group>
                        <Form.Check
                          inline
                          type="checkbox"
                          label="Alcohol"
                          name="habits.alcohol"
                          checked={formData.habits.alcohol}
                          onChange={handleCheckboxChange}
                        />
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group>
                        <Form.Check
                          inline
                          type="checkbox"
                          label="Tobacco"
                          name="habits.tobacco"
                          checked={formData.habits.tobacco}
                          onChange={handleCheckboxChange}
                        />
                      </Form.Group>
                    </Col>
                    <Col>
                      <Form.Group>
                        <Form.Check
                          inline
                          type="checkbox"
                          label="Drugs"
                          name="habits.drugs"
                          checked={formData.habits.drugs}
                          onChange={handleCheckboxChange}
                        />
                      </Form.Group>
                    </Col>
                  </Row>

                  <br />
                  <Row>
                    <Col md={10}>
                      <Form.Group>
                        <Form.Label>Allergy to Any Drug:</Form.Label>
                        <Form.Control
                          as="textarea"
                          name="allergyToDrugs"
                          value={formData.allergyToDrugs}
                          onChange={handleInputChange}
                        />
                      </Form.Group>
                    </Col>
                  </Row>
                  <br />
                  {/* Row 2: Medications Table */}
                  <Form.Label>Medication Details:</Form.Label>
                  <table border="1" className="mb-3" style={{ width: "100%" }}>
                    <thead>
                      <tr>
                        <th>Sr No</th>
                        <th>Name</th>
                        <th>Indication</th>
                        <th>Since</th>
                      </tr>
                    </thead>
                    <tbody>
                      {formData.medications.map((med) => (
                        <tr key={med.id}>
                          <td>{med.id}</td>
                          <td>
                            <input
                              type="text"
                              value={med.name}
                              onChange={(e) =>
                                handleInputChange(e, med.id, "name")
                              }
                              placeholder="Enter medication name"
                            />
                          </td>
                          <td>
                            <input
                              type="text"
                              value={med.indication}
                              onChange={(e) =>
                                handleInputChange(e, med.id, "indication")
                              }
                              placeholder="Enter indication"
                            />
                          </td>
                          <td>
                            <input
                              type="text"
                              value={med.since}
                              onChange={(e) =>
                                handleInputChange(e, med.id, "since")
                              }
                              placeholder="Enter since"
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <br />
                  <Row>
                    <Col md={4}>
                      {/* Add More Button */}
                      <Button
                        variant="primary"
                        onClick={() => {
                          const newId = formData.medications.length + 1;
                          const newMedication = {
                            id: newId,
                            name: "",
                            indication: "",
                            since: "",
                          };
                          setFormData({
                            ...formData,
                            medications: [
                              ...formData.medications,
                              newMedication,
                            ],
                          });
                        }}
                      >
                        Add More
                      </Button>
                    </Col>
                  </Row>
                  <br />
                  <Row>
                    <Col>
                      <Form.Group>
                        <Form.Label>Past Surgical History:</Form.Label>
                        <Form.Control
                          as="textarea"
                          name="pastSurgicalHistory"
                          value={formData.pastSurgicalHistory}
                          onChange={handleInputChange}
                        />
                      </Form.Group>
                    </Col>
                  </Row>
                  <br />
                  <Row>
                    <Col>
                      <Form.Group>
                        <Form.Label>Any Other Complaints:</Form.Label>
                        <Form.Control
                          as="textarea"
                          name="anyOtherComplaints"
                          value={formData.anyOtherComplaints}
                          onChange={handleInputChange}
                        />
                      </Form.Group>
                    </Col>
                  </Row>
                  <br />
                  <Row>
                    <Col>
                      <Form.Group>
                        <Form.Label>Present Complaints:</Form.Label>
                        <Form.Control
                          as="textarea"
                          name="presentComplaints"
                          value={formData.presentComplaints}
                          onChange={handleInputChange}
                        />
                      </Form.Group>
                    </Col>
                  </Row>
                  <br />
                  <Row className="mb-3">
                    <Col>
                      <Form.Label>Ongoing Medicines:</Form.Label>
                      <Row>
                        <Col>
                          <Form.Check
                            inline
                            type="checkbox"
                            label="Clopidogrel"
                            name="ongoing_medicines.Clopidogrel"
                            checked={formData.ongoing_medicines.Clopidogrel}
                            onChange={handleCheckboxChange}
                          />
                        </Col>
                        <Col>
                          <Form.Check
                            inline
                            type="checkbox"
                            label="Aspirin"
                            name="ongoing_medicines.aspirin"
                            checked={formData.ongoing_medicines.aspirin}
                            onChange={handleCheckboxChange}
                          />
                        </Col>
                        <Col>
                          <Form.Check
                            inline
                            type="checkbox"
                            label="Warfarin"
                            name="ongoing_medicines.warfarin"
                            checked={formData.ongoing_medicines.warfarin}
                            onChange={handleCheckboxChange}
                          />
                        </Col>
                        <Col xs={3}>
                          <Form.Control
                            as="textarea"
                            placeholder="Any Other"
                            name="otherongoingmedi"
                            value={formData.otherongoingmedi || ""}
                            onChange={handleInputChange}
                          />
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  <br />
                  <Row>
                    <Col md={15}>
                      <Form.Label>Previous Investigation:</Form.Label>
                      <Row>
                        <Col>
                          <div className="d-flex flex-wrap">
                            {[
                              { label: "HB", name: "investigation.hb" },
                              { label: "BSL-R", name: "investigation.bslr" },
                              {
                                label: "Bleeding Time-BT",
                                name: "investigation.bleedingTimeBt",
                              },
                              {
                                label: "Clotting Time-BT",
                                name: "investigation.clottingTimeBt",
                              },
                              {
                                label: "PT INR",
                                name: "investigation.ptInr",
                              },
                              { label: "HIV", name: "investigation.hiv" },
                              { label: "Hbsag", name: "investigation.hbsag" },
                              {
                                label: "SR.Creatinine",
                                name: "investigation.srCreatinine",
                              },
                              {
                                label: "VIT B12",
                                name: "investigation.vitB",
                              },
                            ].map((item, index) => (
                              <div key={index} className="me-3">
                                <Form.Check
                                  inline
                                  type="checkbox"
                                  label={item.label}
                                  name={item.name}
                                  checked={
                                    formData.investigation[
                                      item.name.split(".")[1]
                                    ]
                                  }
                                  onChange={handleCheckboxChange}
                                  disabled={isDisabled}
                                />
                              </div>
                            ))}
                          </div>
                        </Col>
                        <Col>
                          {/* Upload File Section */}
                          <div className="mt-3">
                            <input
                              type="file"
                              id="fileInput"
                              onChange={handleFileChange}
                              className="d-none"
                            />
                            <label
                              htmlFor="fileInput"
                              className="btn btn-primary"
                            >
                              Upload File
                            </label>
                            {selectedFile && (
                              <div className="mt-2 text-primary">
                                <strong>Selected File:</strong>{" "}
                                {selectedFile.name}
                              </div>
                            )}
                          </div>
                        </Col>
                      </Row>
                    </Col>
                    <Col md={8}>
                      <Form.Group>
                        {/* <Form.Label>Investigation Details:</Form.Label> */}
                        <Form.Control
                          as="textarea"
                          name="investigationDetails"
                          placeholder="Investigation Details"
                          value={formData.investigationDetails}
                          onChange={handleInputChange}
                        />
                      </Form.Group>
                    </Col>
                  </Row>
                  <br />
                  <Row>
                    <Col md={10}>
                      <Form.Group>
                        <Form.Label>Known Case Of:</Form.Label>
                        <Form.Control
                          as="textarea"
                          name="knowncaseof"
                          value={formData.knowncaseof}
                          onChange={handleInputChange}
                        />
                      </Form.Group>
                    </Col>
                  </Row>

                  <br />
                  <Row className="mb-3">
                    <Col>
                      <Form.Label>Advice:</Form.Label>
                      <Row>
                        <Col>
                          <Form.Check
                            inline
                            type="checkbox"
                            label="MRD"
                            name="advice.mrd"
                            checked={formData.advice.mrd}
                            onChange={handleCheckboxChange}
                          />
                        </Col>
                        <Col>
                          <Form.Check
                            inline
                            type="checkbox"
                            label="Mano/BF"
                            name="advice.manoBf"
                            checked={formData.advice.manoBf}
                            onChange={handleCheckboxChange}
                          />
                        </Col>
                        <Col>
                          <Form.Check
                            inline
                            type="checkbox"
                            label="Colo/Gstro"
                            name="advice.coloGastro"
                            checked={formData.advice.coloGastro}
                            onChange={handleCheckboxChange}
                          />
                        </Col>
                        <Col>
                          <Form.Check
                            inline
                            type="checkbox"
                            label="MCDPA"
                            name="advice.mcdpa"
                            checked={formData.advice.mcdpa}
                            onChange={handleCheckboxChange}
                          />
                        </Col>
                        <Col>
                          <Form.Check
                            inline
                            type="checkbox"
                            label="Diet"
                            name="advice.diet"
                            checked={formData.advice.diet}
                            onChange={handleCheckboxChange}
                          />
                        </Col>
                        <Col>
                          <Form.Check
                            inline
                            type="checkbox"
                            label="B12"
                            name="advice.b"
                            checked={formData.advice.b}
                            onChange={handleCheckboxChange}
                          />
                        </Col>
                        <Col>
                          <Form.Check
                            inline
                            type="checkbox"
                            label="D3"
                            name="advice.d"
                            checked={formData.advice.d}
                            onChange={handleCheckboxChange}
                          />
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  <Row>
                    <Col md={3}>
                      <Form.Group controlId="assistantsDoctorName">
                        <Form.Label>Assistant Doctor:</Form.Label>
                        <Form.Select
                          value={selectedOptions?.assistantsDoctorName || ""}
                          onChange={(e) =>
                            setSelectedOptions({
                              ...selectedOptions,
                              assistantsDoctorName: e.target.value,
                            })
                          }
                        >
                          <option value="">Select Assistant</option>
                          {[
                            ...new Set([
                              ...patientHistory
                                .map(
                                  (option) =>
                                    option.assistantsDoctorconsultantName
                                )
                                .filter(Boolean),
                              ...assistantsDoctor
                                .map((doctor) => doctor.name)
                                .filter(Boolean),
                            ]),
                          ].map((assistantsDoctorName, index) => (
                            <option key={index} value={assistantsDoctorName}>
                              {assistantsDoctorName}
                            </option>
                          ))}
                        </Form.Select>
                      </Form.Group>
                    </Col>
                  </Row>
                  <br />
                  <Button
                    className="mt-4"
                    onClick={() => handleHistoryClick("save")}
                  >
                    Save Patient History
                  </Button>
                </Form>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      <style>
        {`
          .enquiry-card {
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            border: none;
            background: #f8f9fa;
            overflow: hidden;
            margin-bottom: 30px;
          }

          .card-body {
            padding: 30px;
          }

          .form-section {
            background: #ffffff;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 25px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
          }

          .form-label {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 8px;
            font-size: 0.95rem;
          }

          .form-control, .form-select {
            border-radius: 8px;
            border: 3px solid #dee2e6;
            padding: 12px 15px;
            transition: all 0.3s ease;
            background-color: #ffffff;
            color: #2c3e50;
            font-size: 0.95rem;
          }

          .form-control:focus, .form-select:focus {
            border-color: #00bcd4;
            box-shadow: 0 0 0 3px rgba(0, 188, 212, 0.1);
            background-color: #f8F9FA;
          }

          textarea.form-control {
            min-height: 120px;
            resize: vertical;
          }

          .form-select {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 16px 12px;
          }

          .btn-primary {
            background:linear-gradient(45deg, #00bcd4, #00acc1);
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 188, 212, 0.2);
          }

          .btn-primary:hover {
            background: linear-gradient(45deg, #00acc1, #0097a7);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 188, 212, 0.3);
          }

          .btn-primary:disabled {
            background: #bdc3c7;
            transform: none;
          }

          /* Error message styling */
          .error-message {
            color: #e74c3c;
            font-size: 0.85rem;
            margin-top: 5px;
          }

          /* Responsive adjustments */
          @media (max-width: 768px) {
            .card-body {
              padding: 20px;
            }

            .form-section {
              padding: 15px;
            }

            .btn-primary {
              width: 100%;
              margin-top: 15px;
            }
          }

          /* Row spacing */
          .row {
            margin-bottom: 20px;
          }

          /* Spinner styling */
          .spinner-border {
            margin-right: 8px;
            width: 1.2rem;
            height: 1.2rem;
          }

          /* Optional: Add animation for form elements */
          .form-control, .form-select, .btn {
            animation: fadeIn 0.5s ease-in-out;
          }

          @keyframes fadeIn {
            from {
              opacity: 0;
              transform: translateY(10px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }

          /* Optional: Add hover effect for form controls */
          .form-control:hover, .form-select:hover {
            border-color: #3498db;
          }

          .checkbox-group {
            margin-bottom: 10px;
          }

          .custom-checkbox {
            border: 3px solid #dee2e6;
            border-radius: 8px;
            padding: 10px 15px;
            margin-bottom: 10px;
            display: block;
            transition: all 0.3s ease;
          }

          .custom-checkbox:hover {
            border-color: #00bcd4;
          }

          .custom-checkbox label {
            font-weight: 600;
            color: #2c3e50;
            margin-left: 8px;
          }

          .details-input {
            margin-top: 8px;
            border: 3px solid #dee2e6;
            border-radius: 8px;
            padding: 8px 12px;
            width: 100%;
            transition: all 0.3s ease;
          }

          .details-input:focus {
            border-color: #00bcd4;
            box-shadow: 0 0 0 3px rgba(0, 188, 212, 0.1);
          }

          .other-details-textarea {
            border: 3px solid #dee2e6;
            border-radius: 8px;
            padding: 12px;
            min-height: 80px;
            width: 100%;
            transition: all 0.3s ease;
          }

          .other-details-textarea:focus {
            border-color: #00bcd4;
            box-shadow: 0 0 0 3px rgba(0, 188, 212, 0.1);
          }

          .form-label {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 15px;
          }
        `}
      </style>
    </div>
  );
}
