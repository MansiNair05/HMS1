import React from 'react';

export default function Footer() {
  return (
    <footer className="codex-footer">
        <p>Copyright 2022-23 © medixo All rights reserved.</p>
      </footer>
  )
}
